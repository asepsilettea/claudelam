import { useAuth } from '../context/AuthContext'
import { Icon } from './ui'

export default function Sidebar({ page, setPage }) {
  const { profile, signOut } = useAuth()

  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: 'home' },
    { id: 'projects', label: 'Proyek', icon: 'folder' },
    { id: 'bidang', label: 'Data Bidang', icon: 'map' },
    { id: 'audit', label: 'Audit Trail', icon: 'clock' },
    ...(profile?.role === 'KETUA_PPK' ? [
      { id: 'ppk', label: 'Manajemen PPK', icon: 'users' },
      { id: 'master', label: 'Master Data', icon: 'database' },
    ] : []),
  ]

  const isActive = (id) => page === id || (page === 'bidang-detail' && id === 'bidang')

  return (
    <div style={{ width: 220, background: '#0d1220', borderRight: '1px solid #1e2d44', display: 'flex', flexDirection: 'column', padding: '20px 12px', flexShrink: 0 }}>
      {/* Logo */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '4px 10px', marginBottom: 32 }}>
        <div style={{ width: 36, height: 36, background: 'linear-gradient(135deg, #1d4ed8, #10b981)', borderRadius: 10, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
          <Icon name="map" size={18} color="#fff" />
        </div>
        <div>
          <div style={{ fontSize: 13, fontWeight: 700, color: '#e2e8f0' }}>LAMCS</div>
          <div style={{ fontSize: 10, color: '#475569' }}>v1.0.0</div>
        </div>
      </div>

      {/* Nav */}
      <div style={{ flex: 1 }}>
        <div style={{ fontSize: 10, fontWeight: 700, color: '#334155', letterSpacing: 1, textTransform: 'uppercase', padding: '0 10px', marginBottom: 8 }}>Navigasi</div>
        {navItems.map(item => (
          <div
            key={item.id}
            onClick={() => setPage(item.id)}
            style={{
              display: 'flex', alignItems: 'center', gap: 10,
              padding: '10px 14px', borderRadius: 8, cursor: 'pointer',
              marginBottom: 2, transition: 'all 0.15s',
              background: isActive(item.id) ? '#1e3a5f' : 'transparent',
              color: isActive(item.id) ? '#60a5fa' : '#94a3b8',
              fontSize: 14, fontWeight: 500,
            }}
          >
            <Icon name={item.icon} size={16} color={isActive(item.id) ? '#60a5fa' : '#64748b'} />
            {item.label}
          </div>
        ))}
      </div>

      {/* User */}
      <div style={{ borderTop: '1px solid #1e2d44', paddingTop: 12 }}>
        <div style={{ padding: '8px 10px', marginBottom: 8 }}>
          <div style={{ fontSize: 12, fontWeight: 600, color: '#94a3b8', marginBottom: 4 }}>{profile?.nama}</div>
          <span style={{
            background: profile?.role === 'KETUA_PPK' ? '#1e3a5f' : '#1a2e1a',
            color: profile?.role === 'KETUA_PPK' ? '#60a5fa' : '#6ee7b7',
            padding: '1px 8px', borderRadius: 10, fontSize: 10, fontWeight: 700
          }}>
            {profile?.role === 'KETUA_PPK' ? 'Ketua PPK' : 'PPK'}
          </span>
          {profile?.ppk && (
            <div style={{ fontSize: 10, color: '#475569', marginTop: 4, lineHeight: 1.4 }}>{profile.ppk.nama_ppk}</div>
          )}
        </div>
        <div
          onClick={signOut}
          style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '10px 14px', borderRadius: 8, cursor: 'pointer', color: '#64748b', fontSize: 14, fontWeight: 500 }}
          onMouseEnter={e => { e.currentTarget.style.background = '#1e2535'; e.currentTarget.style.color = '#e2e8f0' }}
          onMouseLeave={e => { e.currentTarget.style.background = 'transparent'; e.currentTarget.style.color = '#64748b' }}
        >
          <Icon name="logout" size={16} color="#64748b" />
          Keluar
        </div>
      </div>
    </div>
  )
}
