import { useEffect, useState } from 'react'
import { useAuth } from '../context/AuthContext'
import { api } from '../lib/api'
import { WORKFLOW_STEPS, WORKFLOW_COLORS, WORKFLOW_LABELS } from '../lib/constants'
import { Icon, LoadingPage, ErrorBox, EmptyState, ProgressBar } from './ui'

export default function ProjectsPage({ setPage, setSelectedProject, showToast }) {
  const { profile } = useAuth()
  const [projects, setProjects] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [showForm, setShowForm] = useState(false)
  const [saving, setSaving] = useState(false)
  const [form, setForm] = useState({ nama_proyek: '', tahun: new Date().getFullYear(), deskripsi: '' })

  const ppkId = profile?.role === 'PPK' ? profile.ppk_id : null

  const load = async () => {
    try {
      setLoading(true)
      setError(null)
      const data = await api.getProjects(ppkId)
      setProjects(data)
    } catch (e) {
      setError(e.message)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { load() }, [])

  const handleCreate = async () => {
    if (!form.nama_proyek.trim()) return showToast('Nama proyek wajib diisi', 'error')
    try {
      setSaving(true)
      await api.createProject({ ...form, ppk_id: ppkId, tahun: parseInt(form.tahun) })
      showToast('Proyek berhasil dibuat')
      setShowForm(false)
      setForm({ nama_proyek: '', tahun: new Date().getFullYear(), deskripsi: '' })
      load()
    } catch (e) {
      showToast(e.message, 'error')
    } finally {
      setSaving(false)
    }
  }

  if (loading) return <LoadingPage text="Memuat proyek..." />
  if (error) return <ErrorBox message={error} onRetry={load} />

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
        <div>
          <h1 style={{ fontSize: 22, fontWeight: 700, color: '#f1f5f9' }}>Manajemen Proyek</h1>
          <p style={{ color: '#64748b', fontSize: 13, marginTop: 4 }}>{projects.length} proyek</p>
        </div>
        {profile?.role === 'PPK' && (
          <button
            onClick={() => setShowForm(!showForm)}
            style={{ padding: '8px 16px', borderRadius: 8, background: '#1d4ed8', color: '#fff', border: 'none', fontSize: 13, fontWeight: 600, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6 }}
          >
            <Icon name="plus" size={14} color="#fff" /> Proyek Baru
          </button>
        )}
      </div>

      {showForm && (
        <div style={{ background: '#161b2e', border: '1px solid #1d4ed8', borderRadius: 12, padding: 20, marginBottom: 20 }}>
          <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: 1, textTransform: 'uppercase', color: '#475569', marginBottom: 16 }}>Buat Proyek Baru</div>
          <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 14, marginBottom: 14 }}>
            <div>
              <label style={{ fontSize: 11, fontWeight: 700, color: '#475569', display: 'block', marginBottom: 6, textTransform: 'uppercase', letterSpacing: 0.5 }}>Nama Proyek *</label>
              <input value={form.nama_proyek} onChange={e => setForm({ ...form, nama_proyek: e.target.value })} placeholder="Pembebasan Tanah Ruas..."
                style={{ background: '#0f1421', border: '1px solid #2d3748', color: '#e2e8f0', borderRadius: 8, padding: '8px 12px', fontSize: 13, width: '100%', fontFamily: 'inherit' }} />
            </div>
            <div>
              <label style={{ fontSize: 11, fontWeight: 700, color: '#475569', display: 'block', marginBottom: 6, textTransform: 'uppercase', letterSpacing: 0.5 }}>Tahun</label>
              <input type="number" value={form.tahun} onChange={e => setForm({ ...form, tahun: e.target.value })}
                style={{ background: '#0f1421', border: '1px solid #2d3748', color: '#e2e8f0', borderRadius: 8, padding: '8px 12px', fontSize: 13, width: '100%', fontFamily: 'inherit' }} />
            </div>
          </div>
          <div style={{ marginBottom: 16 }}>
            <label style={{ fontSize: 11, fontWeight: 700, color: '#475569', display: 'block', marginBottom: 6, textTransform: 'uppercase', letterSpacing: 0.5 }}>Deskripsi</label>
            <input value={form.deskripsi} onChange={e => setForm({ ...form, deskripsi: e.target.value })} placeholder="Opsional..."
              style={{ background: '#0f1421', border: '1px solid #2d3748', color: '#e2e8f0', borderRadius: 8, padding: '8px 12px', fontSize: 13, width: '100%', fontFamily: 'inherit' }} />
          </div>
          <div style={{ display: 'flex', gap: 10 }}>
            <button onClick={handleCreate} disabled={saving}
              style={{ padding: '8px 18px', borderRadius: 8, background: '#1d4ed8', color: '#fff', border: 'none', fontSize: 13, fontWeight: 600, cursor: saving ? 'not-allowed' : 'pointer', display: 'flex', alignItems: 'center', gap: 6 }}>
              <Icon name="check" size={13} color="#fff" /> {saving ? 'Menyimpan...' : 'Simpan'}
            </button>
            <button onClick={() => setShowForm(false)}
              style={{ padding: '8px 18px', borderRadius: 8, background: '#1e2535', color: '#94a3b8', border: '1px solid #2d3748', fontSize: 13, cursor: 'pointer' }}>
              Batal
            </button>
          </div>
        </div>
      )}

      {projects.length === 0
        ? <EmptyState icon="folder" title="Belum ada proyek" subtitle="Klik 'Proyek Baru' untuk memulai" />
        : (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))', gap: 16 }}>
            {projects.map(p => {
              const total = parseInt(p.bidang?.[0]?.count) || 0
              return (
                <div key={p.id}
                  onClick={() => { setSelectedProject(p); setPage('bidang') }}
                  style={{ background: '#161b2e', border: '1px solid #1e2d44', borderRadius: 12, padding: 20, cursor: 'pointer', transition: 'border-color 0.2s' }}
                  onMouseEnter={e => e.currentTarget.style.borderColor = '#3b82f6'}
                  onMouseLeave={e => e.currentTarget.style.borderColor = '#1e2d44'}
                >
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 14 }}>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontSize: 14, fontWeight: 700, color: '#e2e8f0', marginBottom: 4 }}>{p.nama_proyek}</div>
                      <div style={{ fontSize: 11, color: '#475569' }}>{p.ppk?.nama_ppk} · {p.tahun}</div>
                    </div>
                    <span style={{
                      background: p.status_proyek === 'AKTIF' ? '#064e3b' : '#1e2d44',
                      color: p.status_proyek === 'AKTIF' ? '#6ee7b7' : '#64748b',
                      padding: '2px 10px', borderRadius: 10, fontSize: 10, fontWeight: 700, flexShrink: 0, marginLeft: 10
                    }}>{p.status_proyek}</span>
                  </div>

                  <div style={{ display: 'flex', gap: 20, marginBottom: 14 }}>
                    <div>
                      <div style={{ fontSize: 20, fontWeight: 700, color: '#f1f5f9' }}>{total}</div>
                      <div style={{ fontSize: 11, color: '#64748b' }}>Total Bidang</div>
                    </div>
                  </div>
                  <ProgressBar pct={0} />

                  {p.deskripsi && (
                    <div style={{ marginTop: 12, fontSize: 12, color: '#64748b', lineHeight: 1.5 }}>{p.deskripsi}</div>
                  )}
                </div>
              )
            })}
          </div>
        )
      }
    </div>
  )
}
