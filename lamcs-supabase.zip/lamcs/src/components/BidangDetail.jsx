import { useEffect, useState, useCallback } from 'react'
import { useAuth } from '../context/AuthContext'
import { api } from '../lib/api'
import { WORKFLOW_STEPS, WORKFLOW_LABELS, WORKFLOW_COLORS, nextAllowedStatuses, formatLuas, formatRupiah, formatDate } from '../lib/constants'
import { Icon, WorkflowBadge, LoadingPage, ErrorBox, Spinner } from './ui'

export default function BidangDetail({ bidangInit, setPage, showToast, onBack }) {
  const { profile } = useAuth()
  const [bidang, setBidang] = useState(bidangInit)
  const [tab, setTab] = useState('info')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)

  // Sub-data
  const [pihak, setPihak] = useState([])
  const [objek, setObjek] = useState([])
  const [dokumen, setDokumen] = useState([])
  const [history, setHistory] = useState([])
  const [subLoading, setSubLoading] = useState(false)

  // Forms
  const [wfNote, setWfNote] = useState('')
  const [wfSaving, setWfSaving] = useState(false)
  const [editLuas, setEditLuas] = useState(false)
  const [luasForm, setLuasForm] = useState({})
  const [luasSaving, setLuasSaving] = useState(false)
  const [showAddPihak, setShowAddPihak] = useState(false)
  const [showAddObjek, setShowAddObjek] = useState(false)
  const [showAddDokumen, setShowAddDokumen] = useState(false)
  const [pihakForm, setPihakForm] = useState({ jenis: 'PEMILIK', nama: '', nik: '', tempat_lahir: '', tanggal_lahir: '', pekerjaan: '', alamat: '' })
  const [objekForm, setObjekForm] = useState({ jenis_objek: 'BANGUNAN', deskripsi: '', nilai_estimasi: '' })
  const [dokForm, setDokForm] = useState({ kategori: 'KMZ', url: '', deskripsi: '' })

  const canEdit = profile?.role === 'PPK'
  const allowed = nextAllowedStatuses(bidang.workflow_status)

  // Reload full bidang from DB
  const reloadBidang = async () => {
    const fresh = await api.getBidangById(bidang.id)
    setBidang(fresh)
  }

  // Load sub-data by tab
  const loadTab = useCallback(async (t) => {
    setSubLoading(true)
    try {
      if (t === 'pihak') setPihak(await api.getPihak(bidang.id))
      else if (t === 'objek') setObjek(await api.getObjek(bidang.id))
      else if (t === 'dokumen') setDokumen(await api.getDokumen(bidang.id))
      else if (t === 'history') setHistory(await api.getWorkflowHistory(bidang.id))
    } catch (e) { showToast(e.message, 'error') }
    finally { setSubLoading(false) }
  }, [bidang.id])

  useEffect(() => { loadTab(tab) }, [tab])

  // WORKFLOW
  const handleWorkflow = async (newStatus) => {
    if (!allowed.includes(newStatus)) return showToast('Transisi tidak diizinkan', 'error')
    try {
      setWfSaving(true)
      await api.advanceWorkflow(bidang.id, newStatus, profile.id, wfNote)
      await reloadBidang()
      setWfNote('')
      showToast(`Status → ${WORKFLOW_LABELS[newStatus]}`)
      if (tab === 'history') loadTab('history')
    } catch (e) {
      showToast(e.message, 'error')
    } finally {
      setWfSaving(false)
    }
  }

  // LUAS
  const handleLuasSave = async () => {
    try {
      setLuasSaving(true)
      await api.updateLuas(bidang.id, {
        luas_asal: parseFloat(luasForm.luas_asal) || 0,
        luas_terkena: parseFloat(luasForm.luas_terkena) || 0,
        ruang_atas: parseFloat(luasForm.ruang_atas) || 0,
        ruang_bawah: parseFloat(luasForm.ruang_bawah) || 0,
      })
      await reloadBidang()
      setEditLuas(false)
      showToast('Data luas disimpan')
    } catch (e) {
      showToast(e.message, 'error')
    } finally {
      setLuasSaving(false)
    }
  }

  // PIHAK
  const handleAddPihak = async () => {
    if (!pihakForm.nama) return showToast('Nama wajib diisi', 'error')
    try {
      await api.createPihak({ ...pihakForm, bidang_id: bidang.id })
      showToast('Pihak ditambahkan')
      setShowAddPihak(false)
      setPihakForm({ jenis: 'PEMILIK', nama: '', nik: '', tempat_lahir: '', tanggal_lahir: '', pekerjaan: '', alamat: '' })
      loadTab('pihak')
    } catch (e) { showToast(e.message, 'error') }
  }
  const handleDeletePihak = async (id) => {
    try { await api.softDeletePihak(id); loadTab('pihak'); showToast('Pihak dinonaktifkan') }
    catch (e) { showToast(e.message, 'error') }
  }

  // OBJEK
  const handleAddObjek = async () => {
    if (!objekForm.deskripsi) return showToast('Deskripsi wajib diisi', 'error')
    try {
      await api.createObjek({ ...objekForm, bidang_id: bidang.id, nilai_estimasi: parseFloat(objekForm.nilai_estimasi) || 0 })
      showToast('Objek ditambahkan')
      setShowAddObjek(false)
      setObjekForm({ jenis_objek: 'BANGUNAN', deskripsi: '', nilai_estimasi: '' })
      loadTab('objek')
    } catch (e) { showToast(e.message, 'error') }
  }
  const handleDeleteObjek = async (id) => {
    try { await api.deleteObjek(id); loadTab('objek'); showToast('Objek dihapus') }
    catch (e) { showToast(e.message, 'error') }
  }

  // DOKUMEN
  const handleAddDokumen = async () => {
    try {
      await api.createDokumen({ ...dokForm, bidang_id: bidang.id })
      showToast('Dokumen ditambahkan')
      setShowAddDokumen(false)
      setDokForm({ kategori: 'KMZ', url: '', deskripsi: '' })
      loadTab('dokumen')
    } catch (e) { showToast(e.message, 'error') }
  }
  const handleDeleteDokumen = async (id) => {
    try { await api.deleteDokumen(id); loadTab('dokumen'); showToast('Dokumen dihapus') }
    catch (e) { showToast(e.message, 'error') }
  }

  const luas = bidang.bidang_luas?.[0] || bidang.bidang_luas
  const workflowIdx = WORKFLOW_STEPS.indexOf(bidang.workflow_status)

  const inputStyle = { background: '#0f1421', border: '1px solid #2d3748', color: '#e2e8f0', borderRadius: 8, padding: '8px 12px', fontSize: 13, width: '100%', fontFamily: 'inherit' }
  const labelStyle = { fontSize: 11, fontWeight: 700, color: '#475569', display: 'block', marginBottom: 6, textTransform: 'uppercase', letterSpacing: 0.5 }

  return (
    <div>
      {/* Header */}
      <div style={{ marginBottom: 24 }}>
        <button onClick={() => setPage('bidang')} style={{ background: 'none', color: '#64748b', border: 'none', fontSize: 12, cursor: 'pointer', marginBottom: 12 }}>← Kembali ke Daftar Bidang</button>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 6 }}>
              <h1 style={{ fontSize: 24, fontWeight: 700, color: '#f1f5f9', fontFamily: "'DM Mono', monospace" }}>{bidang.nub}</h1>
              <WorkflowBadge status={bidang.workflow_status} large />
            </div>
            <p style={{ color: '#64748b', fontSize: 13 }}>
              NIB: {bidang.nib || '—'} · {bidang.project?.nama_proyek}
            </p>
          </div>
        </div>
      </div>

      {/* Workflow Stepper */}
      <div style={{ background: '#161b2e', border: '1px solid #1e2d44', borderRadius: 12, padding: 20, marginBottom: 20 }}>
        <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: 1, textTransform: 'uppercase', color: '#475569', marginBottom: 16 }}>Alur Workflow</div>
        <div style={{ display: 'flex', alignItems: 'center', overflowX: 'auto', paddingBottom: 8 }}>
          {WORKFLOW_STEPS.slice(0, 5).map((s, i) => {
            const isDone = i < workflowIdx && bidang.workflow_status !== 'DIBATALKAN'
            const isCurrent = s === bidang.workflow_status
            return (
              <div key={s} style={{ display: 'flex', alignItems: 'center', flexShrink: 0 }}>
                <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6 }}>
                  <div style={{ width: 32, height: 32, borderRadius: '50%', border: `2px solid ${isCurrent ? WORKFLOW_COLORS[s] : isDone ? '#10b981' : '#1e2d44'}`, background: isCurrent ? WORKFLOW_COLORS[s] + '30' : isDone ? '#064e3b' : '#0f1421', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    {isDone
                      ? <Icon name="check" size={13} color="#10b981" />
                      : <span style={{ fontSize: 11, fontWeight: 700, color: isCurrent ? WORKFLOW_COLORS[s] : '#475569' }}>{i + 1}</span>}
                  </div>
                  <span style={{ fontSize: 10, fontWeight: 700, color: isCurrent ? WORKFLOW_COLORS[s] : isDone ? '#10b981' : '#475569', whiteSpace: 'nowrap' }}>{WORKFLOW_LABELS[s]}</span>
                </div>
                {i < 4 && <div style={{ width: 40, height: 2, background: isDone && workflowIdx > i + 1 ? '#10b981' : '#1e2d44', margin: '0 4px', marginBottom: 20, flexShrink: 0 }} />}
              </div>
            )
          })}
          {bidang.workflow_status === 'DIBATALKAN' && (
            <div style={{ marginLeft: 16, background: '#7f1d1d30', border: '1px solid #7f1d1d', borderRadius: 8, padding: '6px 14px', display: 'flex', alignItems: 'center', gap: 8 }}>
              <Icon name="x" size={13} color="#ef4444" />
              <span style={{ fontSize: 11, fontWeight: 700, color: '#ef4444' }}>DIBATALKAN</span>
            </div>
          )}
        </div>

        {canEdit && allowed.length > 0 && (
          <div style={{ borderTop: '1px solid #1e2d44', marginTop: 16, paddingTop: 16 }}>
            <div style={{ marginBottom: 10 }}>
              <label style={labelStyle}>Catatan Perubahan (opsional)</label>
              <input value={wfNote} onChange={e => setWfNote(e.target.value)} placeholder="Untuk audit trail..." style={inputStyle} />
            </div>
            <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
              {allowed.map(s => (
                <button key={s} onClick={() => handleWorkflow(s)} disabled={wfSaving}
                  style={{ padding: '8px 18px', borderRadius: 8, background: WORKFLOW_COLORS[s] + '20', color: WORKFLOW_COLORS[s], border: `1px solid ${WORKFLOW_COLORS[s]}40`, fontSize: 13, fontWeight: 600, cursor: wfSaving ? 'not-allowed' : 'pointer', display: 'flex', alignItems: 'center', gap: 6 }}>
                  {wfSaving ? <Spinner size={13} /> : <Icon name={s === 'DIBATALKAN' ? 'x' : 'arrow'} size={13} color={WORKFLOW_COLORS[s]} />}
                  Lanjut ke {WORKFLOW_LABELS[s]}
                </button>
              ))}
            </div>
          </div>
        )}
        {!canEdit && <p style={{ fontSize: 12, color: '#475569', marginTop: 12 }}>* Anda hanya memiliki akses lihat.</p>}
      </div>

      {/* Tabs */}
      <div style={{ display: 'flex', gap: 2, marginBottom: 20, background: '#0f1421', border: '1px solid #1e2d44', borderRadius: 10, padding: 4, width: 'fit-content', flexWrap: 'wrap' }}>
        {[['info','Info'],['luas','Luas'],['pihak','Pihak'],['objek','Objek'],['dokumen','Dokumen'],['history','Audit Trail']].map(([t, l]) => (
          <button key={t} onClick={() => setTab(t)}
            style={{ padding: '7px 14px', borderRadius: 8, fontSize: 12, fontWeight: 600, background: tab === t ? '#1e2d44' : 'transparent', color: tab === t ? '#e2e8f0' : '#64748b', border: 'none', cursor: 'pointer', transition: 'all 0.15s' }}>
            {l}
          </button>
        ))}
      </div>

      {/* ---- TAB: INFO ---- */}
      {tab === 'info' && (
        <div style={{ background: '#161b2e', border: '1px solid #1e2d44', borderRadius: 12, padding: 24 }}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 24 }}>
            {[
              ['NUB', bidang.nub, 'mono'],
              ['NIB', bidang.nib || '—', 'mono'],
              ['Status Tanah', bidang.master_status_tanah ? `${bidang.master_status_tanah.kode} — ${bidang.master_status_tanah.nama_status}` : '—'],
              ['Pembebanan', bidang.pembebanan || '—'],
              ['Rencana Pembangunan', bidang.rencana_pembangunan || '—'],
              ['Keterangan', bidang.keterangan || '—'],
              ['Provinsi', bidang.master_provinsi?.nama || '—'],
              ['Kabupaten', bidang.master_kabupaten?.nama || '—'],
              ['Kecamatan', bidang.master_kecamatan?.nama || '—'],
              ['Desa', bidang.master_desa?.nama || '—'],
              ['Proyek', bidang.project?.nama_proyek || '—'],
              ['PPK', bidang.project?.ppk?.nama_ppk || '—'],
              ['Dibuat Oleh', bidang.users?.nama || '—'],
              ['Tanggal Dibuat', bidang.created_at?.slice(0, 10) || '—'],
              ['Status Aktif', bidang.aktif ? 'Aktif' : 'Nonaktif'],
            ].map(([l, v, type]) => (
              <div key={l}>
                <div style={{ fontSize: 11, fontWeight: 700, color: '#475569', marginBottom: 4, textTransform: 'uppercase', letterSpacing: 0.5 }}>{l}</div>
                <div style={{ fontSize: 13, color: '#e2e8f0', fontFamily: type === 'mono' ? "'DM Mono', monospace" : 'inherit' }}>{v}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ---- TAB: LUAS ---- */}
      {tab === 'luas' && (
        <div style={{ background: '#161b2e', border: '1px solid #1e2d44', borderRadius: 12, padding: 24 }}>
          {editLuas ? (
            <>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14, marginBottom: 14 }}>
                {[['luas_asal','Luas Asal (m²)'],['luas_terkena','Luas Terkena (m²)'],['ruang_atas','Ruang Atas (m²)'],['ruang_bawah','Ruang Bawah (m²)']].map(([k, l]) => (
                  <div key={k}>
                    <label style={labelStyle}>{l}</label>
                    <input type="number" value={luasForm[k] ?? ''} onChange={e => setLuasForm({ ...luasForm, [k]: e.target.value })} style={inputStyle} />
                  </div>
                ))}
              </div>
              <div style={{ fontSize: 12, color: '#64748b', marginBottom: 16 }}>
                Luas Sisa (auto): <strong style={{ color: '#f1f5f9' }}>{formatLuas((parseFloat(luasForm.luas_asal) || 0) - (parseFloat(luasForm.luas_terkena) || 0))}</strong>
              </div>
              <div style={{ display: 'flex', gap: 10 }}>
                <button onClick={handleLuasSave} disabled={luasSaving} style={{ padding: '8px 18px', borderRadius: 8, background: '#064e3b', color: '#6ee7b7', border: 'none', fontSize: 13, fontWeight: 600, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6 }}>
                  {luasSaving ? <Spinner size={13} /> : <Icon name="check" size={13} color="#6ee7b7" />} Simpan
                </button>
                <button onClick={() => setEditLuas(false)} style={{ padding: '8px 18px', borderRadius: 8, background: '#1e2535', color: '#94a3b8', border: '1px solid #2d3748', fontSize: 13, cursor: 'pointer' }}>Batal</button>
              </div>
            </>
          ) : (
            <>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16, marginBottom: 20 }}>
                {[['Luas Asal', luas?.luas_asal],['Luas Terkena', luas?.luas_terkena],['Luas Sisa', luas?.luas_sisa],['Ruang Atas', luas?.ruang_atas]].map(([l, v]) => (
                  <div key={l} style={{ background: '#0f1421', borderRadius: 10, padding: 16 }}>
                    <div style={{ fontSize: 11, fontWeight: 700, color: '#475569', textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 8 }}>{l}</div>
                    <div style={{ fontSize: 18, fontWeight: 700, color: '#f1f5f9', fontFamily: "'DM Mono', monospace" }}>{formatLuas(v)}</div>
                  </div>
                ))}
              </div>
              {canEdit && (
                <button onClick={() => { setLuasForm({ luas_asal: luas?.luas_asal || 0, luas_terkena: luas?.luas_terkena || 0, ruang_atas: luas?.ruang_atas || 0, ruang_bawah: luas?.ruang_bawah || 0 }); setEditLuas(true) }}
                  style={{ padding: '8px 16px', borderRadius: 8, background: '#1e2535', color: '#94a3b8', border: '1px solid #2d3748', fontSize: 13, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6 }}>
                  <Icon name="edit" size={13} /> Edit Data Luas
                </button>
              )}
            </>
          )}
        </div>
      )}

      {/* ---- TAB: PIHAK ---- */}
      {tab === 'pihak' && (
        <div>
          {canEdit && <button onClick={() => setShowAddPihak(!showAddPihak)} style={{ marginBottom: 16, padding: '8px 16px', borderRadius: 8, background: '#1d4ed8', color: '#fff', border: 'none', fontSize: 13, fontWeight: 600, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6 }}><Icon name="plus" size={14} color="#fff" /> Tambah Pihak</button>}
          {showAddPihak && (
            <div style={{ background: '#161b2e', border: '1px solid #1d4ed8', borderRadius: 12, padding: 20, marginBottom: 16 }}>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 14, marginBottom: 14 }}>
                <div><label style={labelStyle}>Jenis</label><select value={pihakForm.jenis} onChange={e => setPihakForm({ ...pihakForm, jenis: e.target.value })} style={inputStyle}><option value="PEMILIK">Pemilik</option><option value="PENGGARAP">Penggarap</option></select></div>
                <div><label style={labelStyle}>Nama *</label><input value={pihakForm.nama} onChange={e => setPihakForm({ ...pihakForm, nama: e.target.value })} style={inputStyle} /></div>
                <div><label style={labelStyle}>NIK</label><input value={pihakForm.nik} onChange={e => setPihakForm({ ...pihakForm, nik: e.target.value })} style={inputStyle} /></div>
                <div><label style={labelStyle}>Tempat Lahir</label><input value={pihakForm.tempat_lahir} onChange={e => setPihakForm({ ...pihakForm, tempat_lahir: e.target.value })} style={inputStyle} /></div>
                <div><label style={labelStyle}>Tanggal Lahir</label><input type="date" value={pihakForm.tanggal_lahir} onChange={e => setPihakForm({ ...pihakForm, tanggal_lahir: e.target.value })} style={inputStyle} /></div>
                <div><label style={labelStyle}>Pekerjaan</label><input value={pihakForm.pekerjaan} onChange={e => setPihakForm({ ...pihakForm, pekerjaan: e.target.value })} style={inputStyle} /></div>
                <div style={{ gridColumn: '1/-1' }}><label style={labelStyle}>Alamat</label><input value={pihakForm.alamat} onChange={e => setPihakForm({ ...pihakForm, alamat: e.target.value })} style={inputStyle} /></div>
              </div>
              <div style={{ display: 'flex', gap: 10 }}>
                <button onClick={handleAddPihak} style={{ padding: '8px 18px', borderRadius: 8, background: '#1d4ed8', color: '#fff', border: 'none', fontSize: 13, fontWeight: 600, cursor: 'pointer' }}>Simpan</button>
                <button onClick={() => setShowAddPihak(false)} style={{ padding: '8px 18px', borderRadius: 8, background: '#1e2535', color: '#94a3b8', border: '1px solid #2d3748', fontSize: 13, cursor: 'pointer' }}>Batal</button>
              </div>
            </div>
          )}
          {subLoading ? <LoadingPage text="Memuat..." /> : (
            <div style={{ background: '#161b2e', border: '1px solid #1e2d44', borderRadius: 12, overflow: 'hidden' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
                <thead><tr>{['Jenis','Nama','NIK','Tempat/Tgl Lahir','Pekerjaan','Alamat',canEdit?'Aksi':''].map(h => h && <th key={h} style={{ background: '#0f1421', color: '#64748b', fontWeight: 600, padding: '10px 14px', textAlign: 'left', borderBottom: '1px solid #1e2d44' }}>{h}</th>)}</tr></thead>
                <tbody>
                  {pihak.length === 0 && <tr><td colSpan={7} style={{ textAlign: 'center', padding: 40, color: '#475569' }}>Belum ada data pihak</td></tr>}
                  {pihak.map(p => (
                    <tr key={p.id} style={{ borderBottom: '1px solid #1a2033' }}>
                      <td style={{ padding: '10px 14px' }}><span style={{ background: p.jenis === 'PEMILIK' ? '#1e3a5f' : '#1a2e1a', color: p.jenis === 'PEMILIK' ? '#60a5fa' : '#6ee7b7', padding: '2px 10px', borderRadius: 10, fontSize: 10, fontWeight: 700 }}>{p.jenis}</span></td>
                      <td style={{ padding: '10px 14px', color: '#e2e8f0', fontWeight: 600 }}>{p.nama}</td>
                      <td style={{ padding: '10px 14px', fontFamily: "'DM Mono', monospace", fontSize: 12, color: '#64748b' }}>{p.nik || '—'}</td>
                      <td style={{ padding: '10px 14px', fontSize: 12, color: '#94a3b8' }}>{p.tempat_lahir}, {p.tanggal_lahir}</td>
                      <td style={{ padding: '10px 14px', color: '#94a3b8' }}>{p.pekerjaan}</td>
                      <td style={{ padding: '10px 14px', fontSize: 12, color: '#94a3b8', maxWidth: 160, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{p.alamat}</td>
                      {canEdit && <td style={{ padding: '10px 14px' }}><button onClick={() => handleDeletePihak(p.id)} style={{ padding: '3px 8px', borderRadius: 6, background: '#7f1d1d', color: '#fca5a5', border: 'none', fontSize: 11, cursor: 'pointer' }}><Icon name="trash" size={11} color="#fca5a5" /></button></td>}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* ---- TAB: OBJEK ---- */}
      {tab === 'objek' && (
        <div>
          {canEdit && <button onClick={() => setShowAddObjek(!showAddObjek)} style={{ marginBottom: 16, padding: '8px 16px', borderRadius: 8, background: '#1d4ed8', color: '#fff', border: 'none', fontSize: 13, fontWeight: 600, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6 }}><Icon name="plus" size={14} color="#fff" /> Tambah Objek</button>}
          {showAddObjek && (
            <div style={{ background: '#161b2e', border: '1px solid #1d4ed8', borderRadius: 12, padding: 20, marginBottom: 16 }}>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 2fr 1fr', gap: 14, marginBottom: 14 }}>
                <div><label style={labelStyle}>Jenis</label><select value={objekForm.jenis_objek} onChange={e => setObjekForm({ ...objekForm, jenis_objek: e.target.value })} style={inputStyle}><option value="BANGUNAN">Bangunan</option><option value="TANAMAN">Tanaman</option><option value="BENDA_LAIN">Benda Lain</option></select></div>
                <div><label style={labelStyle}>Deskripsi *</label><input value={objekForm.deskripsi} onChange={e => setObjekForm({ ...objekForm, deskripsi: e.target.value })} style={inputStyle} /></div>
                <div><label style={labelStyle}>Nilai Estimasi (Rp)</label><input type="number" value={objekForm.nilai_estimasi} onChange={e => setObjekForm({ ...objekForm, nilai_estimasi: e.target.value })} style={inputStyle} /></div>
              </div>
              <div style={{ display: 'flex', gap: 10 }}>
                <button onClick={handleAddObjek} style={{ padding: '8px 18px', borderRadius: 8, background: '#1d4ed8', color: '#fff', border: 'none', fontSize: 13, fontWeight: 600, cursor: 'pointer' }}>Simpan</button>
                <button onClick={() => setShowAddObjek(false)} style={{ padding: '8px 18px', borderRadius: 8, background: '#1e2535', color: '#94a3b8', border: '1px solid #2d3748', fontSize: 13, cursor: 'pointer' }}>Batal</button>
              </div>
            </div>
          )}
          {subLoading ? <LoadingPage text="Memuat..." /> : (
            <div style={{ background: '#161b2e', border: '1px solid #1e2d44', borderRadius: 12, overflow: 'hidden' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
                <thead><tr>{['Jenis','Deskripsi','Nilai Estimasi',canEdit?'Aksi':''].map(h => h && <th key={h} style={{ background: '#0f1421', color: '#64748b', fontWeight: 600, padding: '10px 14px', textAlign: 'left', borderBottom: '1px solid #1e2d44' }}>{h}</th>)}</tr></thead>
                <tbody>
                  {objek.length === 0 && <tr><td colSpan={4} style={{ textAlign: 'center', padding: 40, color: '#475569' }}>Belum ada objek</td></tr>}
                  {objek.map(o => (
                    <tr key={o.id} style={{ borderBottom: '1px solid #1a2033' }}>
                      <td style={{ padding: '10px 14px' }}><span style={{ background: '#1e2d44', color: '#94a3b8', padding: '2px 8px', borderRadius: 6, fontSize: 11, fontWeight: 700 }}>{o.jenis_objek}</span></td>
                      <td style={{ padding: '10px 14px', color: '#e2e8f0' }}>{o.deskripsi}</td>
                      <td style={{ padding: '10px 14px', fontFamily: "'DM Mono', monospace", color: '#f59e0b' }}>{formatRupiah(o.nilai_estimasi)}</td>
                      {canEdit && <td style={{ padding: '10px 14px' }}><button onClick={() => handleDeleteObjek(o.id)} style={{ padding: '3px 8px', borderRadius: 6, background: '#7f1d1d', color: '#fca5a5', border: 'none', fontSize: 11, cursor: 'pointer' }}><Icon name="trash" size={11} color="#fca5a5" /></button></td>}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* ---- TAB: DOKUMEN ---- */}
      {tab === 'dokumen' && (
        <div>
          {canEdit && <button onClick={() => setShowAddDokumen(!showAddDokumen)} style={{ marginBottom: 16, padding: '8px 16px', borderRadius: 8, background: '#1d4ed8', color: '#fff', border: 'none', fontSize: 13, fontWeight: 600, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6 }}><Icon name="plus" size={14} color="#fff" /> Tambah Dokumen</button>}
          {showAddDokumen && (
            <div style={{ background: '#161b2e', border: '1px solid #1d4ed8', borderRadius: 12, padding: 20, marginBottom: 16 }}>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 2fr', gap: 14, marginBottom: 14 }}>
                <div><label style={labelStyle}>Kategori</label><select value={dokForm.kategori} onChange={e => setDokForm({ ...dokForm, kategori: e.target.value })} style={inputStyle}>{['KMZ','VALIDASI','PEMBAYARAN','LAINNYA'].map(k => <option key={k} value={k}>{k}</option>)}</select></div>
                <div><label style={labelStyle}>Deskripsi</label><input value={dokForm.deskripsi} onChange={e => setDokForm({ ...dokForm, deskripsi: e.target.value })} style={inputStyle} /></div>
                <div><label style={labelStyle}>URL * (https://...)</label><input value={dokForm.url} onChange={e => setDokForm({ ...dokForm, url: e.target.value })} placeholder="https://" style={inputStyle} /></div>
              </div>
              <div style={{ display: 'flex', gap: 10 }}>
                <button onClick={handleAddDokumen} style={{ padding: '8px 18px', borderRadius: 8, background: '#1d4ed8', color: '#fff', border: 'none', fontSize: 13, fontWeight: 600, cursor: 'pointer' }}>Simpan</button>
                <button onClick={() => setShowAddDokumen(false)} style={{ padding: '8px 18px', borderRadius: 8, background: '#1e2535', color: '#94a3b8', border: '1px solid #2d3748', fontSize: 13, cursor: 'pointer' }}>Batal</button>
              </div>
            </div>
          )}
          {subLoading ? <LoadingPage text="Memuat..." /> : (
            <div style={{ background: '#161b2e', border: '1px solid #1e2d44', borderRadius: 12, overflow: 'hidden' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
                <thead><tr>{['Kategori','Deskripsi','URL','Tanggal',canEdit?'Aksi':''].map(h => h && <th key={h} style={{ background: '#0f1421', color: '#64748b', fontWeight: 600, padding: '10px 14px', textAlign: 'left', borderBottom: '1px solid #1e2d44' }}>{h}</th>)}</tr></thead>
                <tbody>
                  {dokumen.length === 0 && <tr><td colSpan={5} style={{ textAlign: 'center', padding: 40, color: '#475569' }}>Belum ada dokumen</td></tr>}
                  {dokumen.map(d => (
                    <tr key={d.id} style={{ borderBottom: '1px solid #1a2033' }}>
                      <td style={{ padding: '10px 14px' }}><span style={{ background: '#1e2d44', color: '#94a3b8', padding: '2px 8px', borderRadius: 6, fontSize: 11, fontWeight: 700 }}>{d.kategori}</span></td>
                      <td style={{ padding: '10px 14px', color: '#e2e8f0' }}>{d.deskripsi || '—'}</td>
                      <td style={{ padding: '10px 14px' }}><a href={d.url} target="_blank" rel="noreferrer" style={{ color: '#60a5fa', fontSize: 12, display: 'flex', alignItems: 'center', gap: 5, textDecoration: 'none' }}><Icon name="link" size={12} color="#60a5fa" />{d.url.length > 45 ? d.url.slice(0, 45) + '…' : d.url}</a></td>
                      <td style={{ padding: '10px 14px', fontSize: 12, color: '#475569' }}>{d.created_at?.slice(0, 10)}</td>
                      {canEdit && <td style={{ padding: '10px 14px' }}><button onClick={() => handleDeleteDokumen(d.id)} style={{ padding: '3px 8px', borderRadius: 6, background: '#7f1d1d', color: '#fca5a5', border: 'none', fontSize: 11, cursor: 'pointer' }}><Icon name="trash" size={11} color="#fca5a5" /></button></td>}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* ---- TAB: HISTORY ---- */}
      {tab === 'history' && (
        <div style={{ background: '#161b2e', border: '1px solid #1e2d44', borderRadius: 12, overflow: 'hidden' }}>
          {subLoading ? <LoadingPage text="Memuat history..." /> : (
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
              <thead><tr>{['Waktu','Status Lama','Status Baru','Diubah Oleh','Catatan'].map(h => <th key={h} style={{ background: '#0f1421', color: '#64748b', fontWeight: 600, padding: '10px 14px', textAlign: 'left', borderBottom: '1px solid #1e2d44', whiteSpace: 'nowrap' }}>{h}</th>)}</tr></thead>
              <tbody>
                {history.length === 0 && <tr><td colSpan={5} style={{ textAlign: 'center', padding: 40, color: '#475569' }}>Belum ada riwayat</td></tr>}
                {history.map(h => (
                  <tr key={h.id} style={{ borderBottom: '1px solid #1a2033' }}>
                    <td style={{ padding: '10px 14px', fontFamily: "'DM Mono', monospace", fontSize: 11, color: '#64748b', whiteSpace: 'nowrap' }}>{formatDate(h.changed_at)}</td>
                    <td style={{ padding: '10px 14px' }}>{h.status_lama ? <WorkflowBadge status={h.status_lama} /> : <span style={{ color: '#334155' }}>—</span>}</td>
                    <td style={{ padding: '10px 14px' }}><WorkflowBadge status={h.status_baru} /></td>
                    <td style={{ padding: '10px 14px', color: '#e2e8f0', fontSize: 12 }}>{h.users?.nama || '—'}</td>
                    <td style={{ padding: '10px 14px', color: '#64748b', fontSize: 12 }}>{h.catatan || '—'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      )}
    </div>
  )
}
